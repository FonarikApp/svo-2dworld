# СВО — 2D МИР v1.6

Android-oriented 2D aviation game in a fictional training environment. The territory screen is a separate player-authored notes board; it is not a live map and contains no operational information.

## Included
- Free flight, campaign, local mission editor, hangar, pilot logbook, achievements and settings.
- Eighteen built-in training missions across eight chapters.
- Three named aircraft: Yakovlev Yak-52, Aero L-39 Albatros and Sukhoi Su-27. Their original 2D vector illustrations are stylized game art, not photogrammetry or certified manufacturer models.
- Flight simulation with throttle, steering, pitch, speed-dependent lift, stall warning, bank response, wind, fog, storm effects, fuel, damage and ground servicing.
- Landing gear and flap controls, including drag and landing-gear checks for landing objectives.
- Touch and keyboard controls. Keyboard: W/S throttle, A/D heading, arrows pitch, Space brake, G gear, F flaps, H service at the base, Esc menu.
- Separate fictional territory sketch with pan, zoom, search, player notes, edit/delete and JSON import/export.
- Pilot career ranks from Recruit through Legend, XP thresholds, achievement milestones, and persistent flight statistics.
- Local progress saves, three distinct generated engine loops, wind and ambient score, plus interface effects and audio settings.
- Offline PWA shell and Android WebView wrapper in landscape orientation.

## Run in browser
Serve the `web` directory over HTTP, for example `python -m http.server 8080` from that directory, then open `http://localhost:8080`.

## Android build
Open `android/` in Android Studio and build the `app` module. GitHub Actions is configured to build debug and unsigned release APKs on pushes to `main`/`master` or by manual workflow dispatch. A signed release still requires an owner-provided signing key.

## Validation and limitations
Run `node tests/smoke.mjs` from the project root. The dependency-free tests cover save migration, persistence, base servicing, mission gates, landing gear requirements, aircraft SVG generation and canvas aircraft drawing, and regression coverage for keyboard/touch input routing, including normalized arrow-key steering and pointer-capture-safe hold controls.

This is a playable development build, not a certified flight simulator or a verified commercial release. Flight handling values are gameplay approximations. Engine and ambient WAV files are original procedural approximations, not real aircraft recordings. Physical Android device QA and signed release packaging have not been performed. The current aircraft are detailed stylized 2D vector illustrations; the generated concept board is not integrated as a set of game sprites. The territory board is intentionally fictional and only stores player-authored game notes.
