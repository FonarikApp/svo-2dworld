const shapes={
 yak52:{
  wing:[[-8,-5],[-15,-13],[-58,-7],[-62,1],[-18,8],[-15,21],[-27,31],[-25,35],[-5,28],[0,25],[5,28],[25,35],[27,31],[15,21],[18,8],[62,1],[58,-7],[15,-13],[8,-5]],
  tail:[[-5,23],[-30,32],[-31,36],[-5,32],[0,31],[5,32],[31,36],[30,32],[5,23]],
  canopy:[[-5,-23],[-4,-6],[0,-2],[4,-6],[5,-23],[0,-30]],
  details:'prop'
 },
 l39:{
  wing:[[-6,-7],[-16,-11],[-53,3],[-61,12],[-59,17],[-15,11],[-12,22],[-25,33],[-24,37],[-4,29],[0,26],[4,29],[24,37],[25,33],[12,22],[15,11],[59,17],[61,12],[53,3],[16,-11],[6,-7]],
  tail:[[-5,25],[-25,34],[-25,38],[-4,32],[0,30],[4,32],[25,38],[25,34],[5,25]],
  canopy:[[-5,-30],[-4,-8],[0,-3],[4,-8],[5,-30],[0,-36]],
  details:'jet'
 },
 su27:{
  wing:[[-7,-7],[-17,-13],[-37,-4],[-66,13],[-68,21],[-60,24],[-17,13],[-15,23],[-28,37],[-26,41],[-4,31],[0,29],[4,31],[26,41],[28,37],[15,23],[17,13],[60,24],[68,21],[66,13],[37,-4],[17,-13],[7,-7]],
  tail:[[-7,18],[-36,30],[-39,42],[-30,45],[-8,33],[0,32],[8,33],[30,45],[39,42],[36,30],[7,18]],
  canopy:[[-5,-31],[-5,-8],[0,-2],[5,-8],[5,-31],[0,-37]],
  details:'twin'
 }
};
export function drawAircraft(ctx,id='yak52',damage=0,elapsed=0,scale=1){
 const s=shapes[id]||shapes.yak52,paint=damage>60?'#8b5b50':id==='su27'?'#84949a':id==='l39'?'#b5b9b0':'#b5a17b';
 ctx.save();ctx.scale(scale,scale);
 ctx.shadowColor='#0009';ctx.shadowBlur=13;ctx.shadowOffsetY=8;
 const path=(pts)=>{ctx.beginPath();pts.forEach(([x,y],i)=>i?ctx.lineTo(x,y):ctx.moveTo(x,y));ctx.closePath()};
 const metal=ctx.createLinearGradient(-65,0,65,0);metal.addColorStop(0,'#39464a');metal.addColorStop(.48,paint);metal.addColorStop(1,'#303d43');
 ctx.fillStyle=metal;path(s.wing);ctx.fill();
 ctx.shadowBlur=0;ctx.strokeStyle='#d9ded5';ctx.lineWidth=.7;path(s.wing);ctx.stroke();
 ctx.fillStyle='#29363c';path(s.tail);ctx.fill();
 // Fuselage, nose and tail taper
 const fuselage=ctx.createLinearGradient(-6,0,6,0);fuselage.addColorStop(0,'#536269');fuselage.addColorStop(.5,'#d3d7d0');fuselage.addColorStop(1,'#59666b');ctx.fillStyle=fuselage;
 ctx.beginPath();ctx.moveTo(0,-43);ctx.bezierCurveTo(5,-32,5,-8,4,13);ctx.lineTo(7,26);ctx.lineTo(0,34);ctx.lineTo(-7,26);ctx.lineTo(-4,13);ctx.bezierCurveTo(-5,-8,-5,-32,0,-43);ctx.fill();
 // Cockpit glazing
 ctx.fillStyle='#253d49';path(s.canopy);ctx.fill();ctx.strokeStyle='#c1d0d0';ctx.lineWidth=1;ctx.stroke();
 ctx.fillStyle='#8ba8b2';ctx.globalAlpha=.7;ctx.beginPath();ctx.ellipse(-1,-22,2.1,8,-.08,0,Math.PI*2);ctx.fill();ctx.globalAlpha=1;
 // Control surfaces and panel lines
 ctx.strokeStyle='#26353b';ctx.lineWidth=.8;
 for(const sign of [-1,1]){ctx.beginPath();ctx.moveTo(sign*17,5);ctx.lineTo(sign*54,13);ctx.stroke();ctx.beginPath();ctx.moveTo(sign*15,18);ctx.lineTo(sign*26,31);ctx.stroke()}
 ctx.strokeStyle='#e3e2d3';ctx.lineWidth=1.1;ctx.beginPath();ctx.moveTo(-7,14);ctx.lineTo(-7,23);ctx.moveTo(7,14);ctx.lineTo(7,23);ctx.stroke();
 if(s.details==='prop'){const spin=Math.sin(elapsed*34)*10;ctx.strokeStyle='#e8e4d6';ctx.lineWidth=2.2;ctx.beginPath();ctx.moveTo(-spin,-43);ctx.lineTo(spin,-43);ctx.stroke();ctx.fillStyle='#20292e';ctx.beginPath();ctx.arc(0,-43,2.5,0,Math.PI*2);ctx.fill()}
 if(s.details==='twin'){ctx.fillStyle='#253239';[-1,1].forEach(k=>{ctx.beginPath();ctx.ellipse(k*8,20,3,11,0,0,Math.PI*2);ctx.fill()});ctx.fillStyle='#d1d6d0';[-1,1].forEach(k=>{ctx.beginPath();ctx.moveTo(k*15,29);ctx.lineTo(k*21,43);ctx.lineTo(k*18,43);ctx.lineTo(k*12,31);ctx.fill()})}
 if(damage>20){ctx.strokeStyle=`rgba(35,20,15,${Math.min(.8,damage/130)})`;ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(-35,7);ctx.lineTo(-21,13);ctx.lineTo(-30,19);ctx.stroke()}
 ctx.restore()
}
export function aircraftSvg(id='yak52'){
 const s=shapes[id]||shapes.yak52,points=s.wing.map(p=>p.join(',')).join(' ');
 return `<svg viewBox="-78 -52 156 112" role="img" aria-label="Схема самолёта"><defs><linearGradient id="metal" x1="0" x2="1"><stop stop-color="#39464a"/><stop offset=".5" stop-color="${id==='su27'?'#84949a':id==='l39'?'#b5b9b0':'#b5a17b'}"/><stop offset="1" stop-color="#303d43"/></linearGradient></defs><polygon points="${points}" fill="url(#metal)" stroke="#d9ded5" stroke-width="1.3"/><path d="M0 -44 C5 -30 5 -5 4 13 L7 26 L0 35 -7 26 -4 13 C-5 -5 -5 -30 0 -44Z" fill="#aeb9b6" stroke="#26353b"/><path d="M-5 -31 Q0 -39 5 -31 L4 -8 0 -2 -4 -8Z" fill="#253d49" stroke="#c1d0d0"/><path d="M-17 5L-54 13M17 5L54 13" stroke="#26353b" fill="none"/></svg>`;
}
