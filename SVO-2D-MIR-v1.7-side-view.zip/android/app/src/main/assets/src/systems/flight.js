
function drawSideAircraft(ctx,id,damage,elapsed,stall=false){
 const jet=id!=='yak52',fighter=id==='su27',s=fighter?1.18:jet?1:.88;
 ctx.save();ctx.scale(s,s);ctx.translate(0,0);
 // Exhaust plume and hot core on jet aircraft.
 if(jet){const pulse=.7+Math.sin(elapsed*.11)*.18;const grad=ctx.createLinearGradient(-170,0,-42,0);grad.addColorStop(0,'rgba(255,118,37,0)');grad.addColorStop(.55,`rgba(255,117,40,${pulse*.28})`);grad.addColorStop(1,'rgba(255,210,132,.65)');ctx.fillStyle=grad;ctx.beginPath();ctx.moveTo(-168,-5);ctx.lineTo(-55,-11);ctx.lineTo(-42,0);ctx.lineTo(-55,11);ctx.lineTo(-168,5);ctx.closePath();ctx.fill()}
 // Drop shadow and fuselage silhouette, nose points right.
 ctx.shadowColor='#000b';ctx.shadowBlur=16;ctx.shadowOffsetY=10;
 const body=ctx.createLinearGradient(0,-24,0,24);body.addColorStop(0,'#a8b0ac');body.addColorStop(.22,'#68777a');body.addColorStop(.58,'#34434a');body.addColorStop(.82,'#202d34');body.addColorStop(1,'#111b21');
 ctx.fillStyle=body;ctx.beginPath();ctx.moveTo(-130,-5);ctx.lineTo(-100,-13);ctx.lineTo(-35,-17);ctx.lineTo(30,-15);ctx.lineTo(92,-10);ctx.lineTo(137,-3);ctx.quadraticCurveTo(151,0,137,4);ctx.lineTo(88,10);ctx.lineTo(15,14);ctx.lineTo(-60,12);ctx.lineTo(-112,7);ctx.closePath();ctx.fill();ctx.shadowBlur=0;ctx.shadowOffsetY=0;
 // Tailplane, fin and wing geometry.
 ctx.fillStyle='#35454c';ctx.beginPath();ctx.moveTo(-100,-8);ctx.lineTo(-125,-43);ctx.lineTo(-106,-39);ctx.lineTo(-65,-11);ctx.closePath();ctx.fill();
 ctx.fillStyle='#667579';ctx.beginPath();ctx.moveTo(-95,-5);ctx.lineTo(-113,-27);ctx.lineTo(-103,-25);ctx.lineTo(-73,-8);ctx.closePath();ctx.fill();
 ctx.fillStyle='#26363d';ctx.beginPath();ctx.moveTo(-55,2);ctx.lineTo(2,-38);ctx.lineTo(54,-31);ctx.lineTo(20,4);ctx.closePath();ctx.fill();
 ctx.fillStyle='#718087';ctx.beginPath();ctx.moveTo(-40,-1);ctx.lineTo(5,-29);ctx.lineTo(34,-27);ctx.lineTo(4,-2);ctx.closePath();ctx.fill();
 ctx.fillStyle='#1c2a31';ctx.beginPath();ctx.moveTo(-52,6);ctx.lineTo(12,31);ctx.lineTo(68,26);ctx.lineTo(18,4);ctx.closePath();ctx.fill();
 // Cockpit canopy with framing and reflections.
 ctx.fillStyle='#101d25';ctx.beginPath();ctx.moveTo(39,-13);ctx.lineTo(53,-31);ctx.quadraticCurveTo(72,-39,88,-12);ctx.lineTo(79,-8);ctx.closePath();ctx.fill();
 ctx.fillStyle='#8da4a8';ctx.globalAlpha=.72;ctx.beginPath();ctx.moveTo(48,-14);ctx.lineTo(59,-28);ctx.quadraticCurveTo(72,-32,81,-13);ctx.closePath();ctx.fill();ctx.globalAlpha=1;
 ctx.strokeStyle='#17242a';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(58,-27);ctx.lineTo(63,-12);ctx.stroke();
 // Panel seams, access covers, markings and warning paint.
 ctx.strokeStyle='rgba(218,224,216,.35)';ctx.lineWidth=1.2;ctx.beginPath();ctx.moveTo(-88,-7);ctx.lineTo(-28,-10);ctx.lineTo(24,-9);ctx.stroke();ctx.beginPath();ctx.moveTo(99,-6);ctx.lineTo(126,-2);ctx.stroke();
 ctx.fillStyle='#c5bda2';ctx.fillRect(-72,-5,23,3);ctx.fillRect(5,7,18,2);ctx.fillStyle='#a94c3d';ctx.fillRect(-118,-4,13,4);
 if(!jet){ctx.strokeStyle='#c2c9c2';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(-135,-29);ctx.lineTo(-135,29);ctx.stroke();ctx.globalAlpha=.55;ctx.beginPath();ctx.ellipse(-135,0,8,34,0,0,Math.PI*2);ctx.stroke();ctx.globalAlpha=1}
 else {ctx.fillStyle='#17232a';ctx.fillRect(-140,-8,28,16);ctx.fillStyle='#819094';ctx.fillRect(-143,-5,5,10);if(fighter){ctx.fillRect(-119,8,28,9);ctx.fillRect(35,12,29,7)}}
 // Landing gear, wheels and struts.
 ctx.strokeStyle='#aeb6b0';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(-15,10);ctx.lineTo(-25,34);ctx.moveTo(51,7);ctx.lineTo(59,29);ctx.stroke();ctx.fillStyle='#11171b';ctx.beginPath();ctx.ellipse(-27,37,8,5,0,0,Math.PI*2);ctx.ellipse(61,32,7,5,0,0,Math.PI*2);ctx.fill();
 // Damage: soot, sparks and persistent smoke trailing behind.
 if(damage>18){ctx.fillStyle='rgba(20,23,23,.62)';ctx.beginPath();ctx.ellipse(-80,-7,14,5,.2,0,Math.PI*2);ctx.fill();ctx.strokeStyle=`rgba(35,37,35,${Math.min(.75,damage/130)})`;ctx.lineWidth=8+damage*.06;ctx.beginPath();ctx.moveTo(-100,-8);ctx.bezierCurveTo(-135,-18,-150+Math.sin(elapsed*.1)*9,-2,-190,Math.sin(elapsed*.08)*18);ctx.stroke()}
 if(damage>58){ctx.fillStyle='#ff9a43';ctx.globalAlpha=.7;ctx.beginPath();ctx.arc(-57,8,2+Math.sin(elapsed*.4)*1.5,0,Math.PI*2);ctx.fill();ctx.globalAlpha=1}
 if(stall){ctx.strokeStyle='#d7b16b';ctx.lineWidth=1;ctx.setLineDash([4,5]);ctx.beginPath();ctx.ellipse(0,0,165,45,0,0,Math.PI*2);ctx.stroke();ctx.setLineDash([])}
 ctx.restore();
}


export function normalizeFlightKey(key){const k=String(key||'').toLowerCase();return ({arrowleft:'a',arrowright:'d',arrowup:'arrowup',arrowdown:'arrowdown',' ':' '})[k]||k}
export class Flight{
 constructor(canvas,store,onFrame,onComplete,plane={accel:1,turn:1,durability:74},audio=null){
  this.plane=plane;this.audio=audio;this.c=canvas;this.ctx=canvas.getContext('2d');this.store=store;this.onFrame=onFrame;this.onComplete=onComplete;this.running=false;this.speed=0;this.altitude=0;this.fuel=100;this.damage=0;this.heading=0;this.x=0;this.y=0;this.elapsed=0;this.wind=0;this.inputKeys={};this.mission=null;this.last=0;this.paused=false;this.objectiveTime=0;this.completed=false;this.weather='ЯСНО';this.difficulty=store.data.difficulty||'normal';this.verticalSpeed=0;this.pitch=0;this.distance=0;this.maxAltitude=0;this.maxSpeed=0;this.landed=false;this.crashed=false;this.cameraShake=0;this.gearDown=true;this.flaps=false;this.stall=false;this.bank=0;this.cloudSeed=Array.from({length:22},(_,i)=>({x:(i*173)%1000,y:(i*97)%520,s:24+(i%5)*13,a:.12+(i%4)*.035}));
 }
 start(m){this.mission=m;this.running=true;this.last=performance.now();this.loop=this.loop.bind(this);this.audio?.startEngine(this.plane.id);requestAnimationFrame(this.loop)}
 pause(v){this.paused=v}
 stop(){this.running=false;this.audio?.stopEngine()}
 setKeys(k){this.inputKeys=k||{}}
 loop(t){if(!this.running)return;const dt=Math.min(.04,Math.max(0,(t-this.last)/1000));this.last=t;if(!this.paused){this.update(dt);if(this.checkObjective()){this.completed=true;this.stop();this.onComplete?.(true)}else if((this.fuel<=0&&this.speed<=2)||this.damage>=100){this.crashed=this.damage>=100;this.stop();this.onComplete?.(false)}}this.draw();this.onFrame?.();if(this.running)requestAnimationFrame(this.loop)}
 update(dt){this.elapsed+=dt;const damageBefore=this.damage;const k=this.inputKeys,easy=this.difficulty==='easy',hard=this.difficulty==='hard';const accel=(easy?29:hard?18:23)*(this.plane.accel||1),turn=(easy?2.05:hard?1.08:1.55)*(this.plane.turn||1);
  const oldSpeed=this.speed;if(k.w)this.speed+=accel*dt;if(k.s)this.speed-=30*dt;if(k[' '])this.speed-=48*dt;const maxSpeed=this.plane.maxSpeed||205;this.speed=Math.max(0,Math.min(maxSpeed,this.speed));if(k.a)this.heading-=turn*dt;if(k.d)this.heading+=turn*dt;this.bank+=( (k.a?-1:0)+(k.d?1:0) )*dt*2.6;this.bank*=Math.max(0,1-dt*1.1);this.heading=(this.heading+Math.PI*2)%(Math.PI*2);
  if(k.arrowup)this.pitch=Math.min(1,this.pitch+dt*1.8);else if(k.arrowdown)this.pitch=Math.max(-1,this.pitch-dt*1.8);else this.pitch*=Math.max(0,1-dt*1.25);const stallSpeed=(this.plane.stallSpeed||55)*(this.flaps?.82:1);this.stall=this.speed<stallSpeed&&this.altitude>15;const lift=Math.max(-.55,Math.min(.55,(this.speed-(stallSpeed+18))/Math.max(70,stallSpeed*1.3)));const flapLift=this.flaps&&this.speed<stallSpeed*1.65?12:0;this.verticalSpeed=(lift*82+flapLift+this.pitch*(easy?125:hard?92:108));if(this.stall)this.verticalSpeed=Math.min(this.verticalSpeed,-28);if(this.speed<25)this.verticalSpeed=Math.min(this.verticalSpeed,-65);this.altitude=Math.max(0,Math.min(4200,this.altitude+this.verticalSpeed*dt));if(this.altitude===0&&this.speed<48)this.verticalSpeed=0;
  const dx=Math.sin(this.heading)*this.speed*dt*.9,dy=-Math.cos(this.heading)*this.speed*dt*.9;this.x+=dx;this.y+=dy;this.distance+=Math.hypot(dx,dy);this.maxAltitude=Math.max(this.maxAltitude,this.altitude);this.maxSpeed=Math.max(this.maxSpeed,this.speed);
  const priorWeather=this.weather;this.wind=Math.sin(this.elapsed*.43)* (hard?16:easy?5:10)+(this.weather==='ШТОРМ'?Math.sin(this.elapsed*2.8)*7:0);this.weather=this.elapsed%90>66?'ТУМАН':this.elapsed%90>42?'ШТОРМ':this.elapsed%90>20?'ВЕТЕР':'ЯСНО';if(this.weather!==priorWeather&&this.audio)this.audio.effect('switch');
  if(this.altitude<18&&this.speed>105)this.damage=Math.min(100,this.damage+dt*(hard?6:3)*(100/(this.plane.durability||74)));
  if(this.altitude<5&&this.speed>70)this.damage=Math.min(100,this.damage+dt*2.8);if(this.altitude<8&&this.speed>45&&!this.gearDown)this.damage=Math.min(100,this.damage+dt*1.8);if(this.stall&&this.pitch>.25)this.damage=Math.min(100,this.damage+dt*.22);
  if(this.altitude<5&&this.speed<15&&this.distance>450&&this.gearDown){if(!this.landed)this.audio?.success();this.landed=true;this.damage=Math.max(0,this.damage-dt*.25)}
  const gearDrag=this.gearDown&&this.speed>35?.012:0,flapDrag=this.flaps?.009:0;this.speed=Math.max(0,this.speed-(gearDrag+flapDrag)*this.speed*dt);this.fuel=Math.max(0,this.fuel-dt*(.035+this.speed/1450+(k.w?.018:0)));if(this.fuel<=0)this.speed=Math.max(0,this.speed-13*dt);
  if(this.audio&&[20,50,80].some(v=>damageBefore<v&&this.damage>=v))this.audio.effect('impact');this.cameraShake=this.damage>65?Math.sin(this.elapsed*28)*(this.damage/65):0;
  const m=this.mission;if(m){let qualifies=this.speed>=m.targetSpeed&&this.altitude>=m.targetAltitude&&this.damage<(m.maxDamage??85)&&this.fuel>=(m.minFuel??1);
   if(m.type==='weather')qualifies=qualifies&&this.weather!=='ЯСНО';
   if(m.type==='heading'){const diff=Math.abs(((this.heading*180/Math.PI-(m.targetHeading||0)+540)%360)-180);qualifies=qualifies&&diff<=(m.headingTolerance||20)}
   if(m.type==='altitude')qualifies=qualifies&&Math.abs(this.altitude-m.targetAltitude)<=(m.altitudeTolerance||120);
   if(m.type==='route'){const p=m.waypoint||{x:0,y:-1500};qualifies=qualifies&&Math.hypot(this.x-p.x,this.y-p.y)<220}
   if(m.type==='landing')qualifies=this.distance>450&&this.altitude<8&&this.speed<15&&this.gearDown&&Math.hypot(this.x,this.y)<220;
   if(m.requireLanding)qualifies=qualifies&&this.distance>450&&this.altitude<8&&this.speed<15&&this.gearDown&&Math.hypot(this.x,this.y)<220;
   this.objectiveTime=qualifies?this.objectiveTime+dt:(m.requireLanding&&this.objectiveTime>=m.duration?this.objectiveTime:Math.max(0,this.objectiveTime-dt*.35));
  }
 }
 repairAtBase(){if(!this.running||this.altitude>8||this.speed>12||Math.hypot(this.x,this.y)>110)return false;this.damage=0;this.fuel=Math.min(100,this.fuel+45);this.repairedAt=performance.now();return true}
 checkObjective(){if(!this.mission)return false;const m=this.mission;if(m.type==='landing')return this.distance>450&&this.altitude<8&&this.speed<15&&this.gearDown&&Math.hypot(this.x,this.y)<220;return this.objectiveTime>=m.duration&&this.fuel>=(m.minFuel||1)&&this.damage<(m.maxDamage??85)&&(m.type!=='weather'||this.weather!=='ЯСНО')&&(!m.requireLanding||(this.distance>450&&this.altitude<8&&this.speed<15&&this.gearDown&&Math.hypot(this.x,this.y)<220))}
 draw(){const c=this.c,ctx=this.ctx,w=c.width,h=c.height;ctx.clearRect(0,0,w,h);ctx.save();ctx.translate(this.cameraShake,0);
  const phase=(Math.sin(this.elapsed*.018)+1)/2,weather=this.weather;const sky=['#101820','#293a43','#554d43','#111923'][Math.min(3,Math.floor(phase*4))];const g=ctx.createLinearGradient(0,0,0,h);g.addColorStop(0,weather==='ТУМАН'?'#87969a':sky);g.addColorStop(.56,'#83918b');g.addColorStop(.57,'#30483d');g.addColorStop(1,'#172c2a');ctx.fillStyle=g;ctx.fillRect(0,0,w,h);
  // Sun bloom and layered distant ridgelines give the training area more depth.
  const sunX=w*.78,sunY=h*.17,sun=ctx.createRadialGradient(sunX,sunY,2,sunX,sunY,Math.min(w,h)*.2);
  sun.addColorStop(0,'rgba(210,205,183,.13)');sun.addColorStop(1,'rgba(255,232,183,0)');
  ctx.fillStyle=sun;ctx.fillRect(sunX-Math.min(w,h)*.2,sunY-Math.min(w,h)*.2,Math.min(w,h)*.4,Math.min(w,h)*.4);
  for(let ridge=0;ridge<3;ridge++){ctx.beginPath();const base=h*.39+ridge*20;ctx.moveTo(0,base+80);for(let i=0;i<=24;i++){const xx=i*w/24,yy=base+Math.sin(i*.78+ridge*1.7+this.x*.00015)*22+Math.cos(i*.31+ridge)*17;ctx.lineTo(xx,yy)}ctx.lineTo(w,h*.55);ctx.lineTo(0,h*.55);ctx.closePath();ctx.fillStyle=['#46534f','#34423f','#263331'][ridge];ctx.globalAlpha=weather==='ТУМАН'?.32:.72-ridge*.12;ctx.fill();ctx.globalAlpha=1}
  const horizon=h*.48+this.altitude*.018;ctx.fillStyle=weather==='ТУМАН'?'#788487':'#394b4c';ctx.beginPath();ctx.moveTo(0,horizon+45);for(let i=0;i<=12;i++){const xx=i*w/12,yy=horizon+Math.sin(i*1.8+this.elapsed*.06)*24+(i%3)*10;ctx.lineTo(xx,yy)}ctx.lineTo(w,h);ctx.lineTo(0,h);ctx.closePath();ctx.fill();
  // Layered procedural hills, fields, roads and a fictional airfield.
  for(let layer=0;layer<3;layer++){const speed=(layer+1)*.16,base=horizon+90+layer*65;ctx.fillStyle=['#34443e','#283833','#1b2b2a'][layer];ctx.beginPath();ctx.moveTo(0,h);for(let i=0;i<=16;i++){const xx=i*w/16,yy=base+Math.sin(i*.9+this.x*.0007*speed+this.y*.0005)*35+Math.cos(i*.41+this.elapsed*.02)*18;ctx.lineTo(xx,yy)}ctx.lineTo(w,h);ctx.closePath();ctx.fill()}
  ctx.strokeStyle='#b7a77988';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(w*.08,h*.83);ctx.bezierCurveTo(w*.35,h*.68,w*.53,h*.93,w*.92,h*.72);ctx.stroke();ctx.strokeStyle='#d4c89b';ctx.lineWidth=1;ctx.stroke();
  for(let i=0;i<16;i++){const xx=(i*139-this.x*.28+5000)%w,yy=horizon+105+(i*61)%230;ctx.fillStyle=i%3?'#273c35':'#52634a';ctx.beginPath();ctx.arc(xx,yy,7+(i%4)*4,0,Math.PI*2);ctx.fill();if(i%4===0){ctx.fillStyle='#b5a27a';ctx.fillRect(xx-7,yy-15,14,10)}}
  // Field boundaries, orchards and isolated farm buildings, all procedural scenery.
  for(let i=0;i<12;i++){const xx=(i*211-this.x*.19+5000)%w,yy=horizon+145+(i*73)%260;ctx.save();ctx.translate(xx,yy);ctx.rotate((i%3-.9)*.13);ctx.strokeStyle='rgba(205,190,143,.22)';ctx.lineWidth=2;ctx.strokeRect(-22,-11,44,22);ctx.fillStyle=i%2?'#31483a':'#3d513b';ctx.fillRect(-18,-8,36,16);if(i%3===0){ctx.fillStyle='#9d8b69';ctx.fillRect(-8,-13,16,8);ctx.fillStyle='#4c5350';ctx.fillRect(-5,-17,10,5)}ctx.restore()}
  // Distant clouds move with the world; fog reduces contrast.
  this.cloudSeed.forEach((cl,i)=>{const xx=(cl.x-this.x*.035+i*13+1400)%1120-60,yy=(cl.y+Math.sin(this.elapsed*.12+i)*8)%340;ctx.fillStyle=`rgba(235,239,232,${weather==='ТУМАН'?cl.a*1.8:cl.a})`;ctx.beginPath();ctx.ellipse(xx,yy,cl.s,cl.s*.27,0,0,Math.PI*2);ctx.fill()});
  // Runway and home beacon in the lower distance, aligned with the fictional base.
  const baseDx=-this.x*.055,baseDy=this.y*.045;ctx.save();ctx.translate(w/2+baseDx,h*.78+baseDy);ctx.fillStyle='#202b30';ctx.beginPath();ctx.moveTo(-42,-8);ctx.lineTo(42,-8);ctx.lineTo(170,185);ctx.lineTo(-170,185);ctx.closePath();ctx.fill();ctx.strokeStyle='#d7d2b7';ctx.lineWidth=3;ctx.setLineDash([16,13]);ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(0,185);ctx.stroke();ctx.setLineDash([]);ctx.fillStyle='#d6a85e';ctx.font='bold 12px monospace';ctx.fillText('АЭРОДРОМ',-44,-18);ctx.restore();
  // Detailed planform rendering for the selected real-world airframe.
  // Strict side-on camera: the aircraft stays in profile while the world streams past.
  const aircraftY=Math.max(h*.34,Math.min(h*.69,h*.53-this.altitude*.018));
  ctx.save();ctx.translate(w*.43,aircraftY);ctx.rotate(Math.max(-.12,Math.min(.12,this.pitch*.055)));drawSideAircraft(ctx,this.plane.id,this.damage,this.elapsed,this.stall);ctx.restore();
  // Low-frequency vibration, lens grime and cinematic vignette.
  const vignette=ctx.createRadialGradient(w*.48,h*.48,Math.min(w,h)*.18,w*.48,h*.48,Math.max(w,h)*.72);vignette.addColorStop(0,'rgba(0,0,0,0)');vignette.addColorStop(1,'rgba(2,7,11,.62)');ctx.fillStyle=vignette;ctx.fillRect(0,0,w,h);
  if(this.weather==='ШТОРМ'){const flash=(Math.sin(this.elapsed*.73)+Math.sin(this.elapsed*.19))>1.78;if(flash){ctx.fillStyle='rgba(215,225,230,.15)';ctx.fillRect(0,0,w,h);ctx.strokeStyle='rgba(226,230,224,.85)';ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(w*.76,0);ctx.lineTo(w*.72,h*.18);ctx.lineTo(w*.79,h*.22);ctx.lineTo(w*.68,h*.43);ctx.stroke()}}
  // Instrument strip and navigation indicators.
  ctx.fillStyle='#0b151dcc';ctx.fillRect(14,14,235,100);ctx.fillStyle='#e8edf0';ctx.font='bold 15px monospace';ctx.fillText(`КУРС ${Math.round(this.heading*180/Math.PI)}°`,26,39);ctx.font='12px monospace';ctx.fillStyle='#d6a85e';ctx.fillText(`ВЕРТИКАЛЬ ${this.verticalSpeed>=0?'+':''}${Math.round(this.verticalSpeed)} м/с`,26,61);ctx.fillText(`ДИСТАНЦИЯ ${Math.round(this.distance)} м`,26,82);ctx.fillStyle='#e8edf0';ctx.fillText(`ВЕТЕР ${this.wind.toFixed(1)} · ${weather}`,26,102);if(this.stall){ctx.fillStyle='#e47d69';ctx.font='bold 15px monospace';ctx.fillText('СВАЛИВАНИЕ · ДОБАВЬ СКОРОСТЬ',w/2-145,h*.28)}ctx.fillStyle='#d6a85e';ctx.font='10px monospace';ctx.fillText(`ШАССИ ${this.gearDown?'ВЫПУЩЕНО':'УБРАНО'} · ЗАКРЫЛКИ ${this.flaps?'ВЫПУЩЕНЫ':'УБРАНЫ'}`,26,122);
  ctx.fillStyle='#0b151ddd';ctx.fillRect(w-218,14,204,112);ctx.fillStyle='#e8edf0';ctx.font='bold 10px monospace';ctx.fillText('ПИЛОТАЖНЫЕ ПРИБОРЫ',w-207,29);
  const gauge=(cx,cy,r,value,max,label)=>{ctx.save();ctx.translate(cx,cy);ctx.fillStyle='#111d22';ctx.beginPath();ctx.arc(0,0,r,0,Math.PI*2);ctx.fill();ctx.strokeStyle='#9eaa9f';ctx.lineWidth=1.4;ctx.stroke();for(let i=0;i<=10;i++){const a=(-Math.PI*.78)+(i/10)*Math.PI*1.56;ctx.strokeStyle=i%2?'#687a7a':'#e1d9c2';ctx.lineWidth=i%2?1:1.8;ctx.beginPath();ctx.moveTo(Math.cos(a)*(r-5),Math.sin(a)*(r-5));ctx.lineTo(Math.cos(a)*(r-1),Math.sin(a)*(r-1));ctx.stroke()}const a=-Math.PI*.78+Math.min(1,value/max)*Math.PI*1.56;ctx.strokeStyle='#d6a85e';ctx.lineWidth=2.3;ctx.beginPath();ctx.moveTo(0,2);ctx.lineTo(Math.cos(a)*(r-8),Math.sin(a)*(r-8));ctx.stroke();ctx.fillStyle='#f2eee3';ctx.beginPath();ctx.arc(0,0,2.5,0,Math.PI*2);ctx.fill();ctx.fillStyle='#e4e9e2';ctx.font='8px monospace';ctx.textAlign='center';ctx.fillText(label,0,r+10);ctx.restore()};
  gauge(w-165,76,25,this.speed,200,'СКОРОСТЬ');gauge(w-76,76,25,this.altitude,2500,'ВЫСОТА');
  ctx.fillStyle=this.damage>55?'#d36a5d':'#75b99b';ctx.font='9px monospace';ctx.fillText(`СОСТОЯНИЕ ${Math.round(100-this.damage)}%`,w-205,118);
  ctx.fillStyle='#0b151dcc';ctx.fillRect(14,h-28,w-28,12);ctx.fillStyle='#d6a85e';ctx.fillRect(17,h-25,(w-34)*this.fuel/100,6);ctx.fillStyle='#e9ece8';ctx.font='10px monospace';ctx.fillText(`ТОПЛИВО ${Math.round(this.fuel)}%`,24,h-35);
  if(this.mission){const pct=this.mission.type==='landing'?Math.min(100,this.distance/1500*100):Math.min(100,this.objectiveTime/this.mission.duration*100);ctx.fillStyle='#0b151ddd';ctx.fillRect(w/2-115,14,230,40);ctx.fillStyle='#fff';ctx.font='bold 12px monospace';ctx.textAlign='center';ctx.fillText(this.mission.type==='landing'?'ВОЗВРАЩЕНИЕ НА БАЗУ':`ЗАДАНИЕ ${pct.toFixed(0)}%`,w/2,31);ctx.fillStyle='#d6a85e';ctx.fillRect(w/2-100,39,200*pct/100,4);ctx.textAlign='left';if(this.mission.waypoint){ctx.fillStyle='#f3d58a';ctx.fillText(`МАЯК · ${Math.round(Math.hypot(this.x-this.mission.waypoint.x,this.y-this.mission.waypoint.y))} м`,w-210,125)}}
  if(weather==='ШТОРМ'){ctx.strokeStyle='#cbd5d477';ctx.lineWidth=1.2;for(let i=0;i<42;i++){const xx=(i*83+this.elapsed*180)%w,yy=(i*47+this.elapsed*320)%h;ctx.beginPath();ctx.moveTo(xx,yy);ctx.lineTo(xx-8,yy+22);ctx.stroke()}}
  if(this.damage>70){ctx.fillStyle=`rgba(130,35,30,${(this.damage-70)/170})`;ctx.fillRect(0,0,w,h)}ctx.restore();
 }
}
