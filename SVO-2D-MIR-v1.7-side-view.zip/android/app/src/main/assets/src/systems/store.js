const KEY='svo2dmir-save-v3';
export class Store{
 constructor(){this.data=this.load()}
 defaults(){return{completed:[],minutes:0,places:[],difficulty:'normal',customMissions:[],selectedPlane:'yak52',sound:true,volume:16,hints:true,xp:0,credits:0,flights:0,bestFlight:0,settings:{}}}
 load(){try{const raw=localStorage.getItem(KEY)||localStorage.getItem('svo2dmir-save-v2')||localStorage.getItem('svo2dmir-save-v1')||'{}';const old=JSON.parse(raw);const data={...this.defaults(),...old,selectedPlane:old.selectedPlane==='falcon'?'yak52':old.selectedPlane==='swift'?'l39':old.selectedPlane==='ursa'?'su27':(old.selectedPlane||'yak52'),completed:Array.isArray(old.completed)?old.completed:[],places:Array.isArray(old.places)?old.places:[],customMissions:Array.isArray(old.customMissions)?old.customMissions:[]};if(!localStorage.getItem(KEY))localStorage.setItem(KEY,JSON.stringify(data));return data}catch{return this.defaults()}}
 save(){try{localStorage.setItem(KEY,JSON.stringify(this.data))}catch(e){console.warn('Save unavailable',e)}}
 reset(){localStorage.removeItem(KEY);localStorage.removeItem('svo2dmir-save-v2');localStorage.removeItem('svo2dmir-save-v1')}
}
