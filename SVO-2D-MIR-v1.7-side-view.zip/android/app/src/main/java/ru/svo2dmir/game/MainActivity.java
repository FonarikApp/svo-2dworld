package ru.svo2dmir.game;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.view.View;

public class MainActivity extends Activity {
  private WebView web;
  @Override public void onCreate(Bundle b){
    super.onCreate(b);
    getWindow().getDecorView().setSystemUiVisibility(5894|1024|512);
    web=new WebView(this);
    WebSettings s=web.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setAllowFileAccess(true);
    s.setAllowFileAccessFromFileURLs(true);
    s.setAllowUniversalAccessFromFileURLs(false);
    s.setMediaPlaybackRequiresUserGesture(false);
    web.setOverScrollMode(View.OVER_SCROLL_NEVER);
    web.setBackgroundColor(0xFF101820);
    setContentView(web);
    web.loadUrl("file:///android_asset/index.html");
  }
  @Override public void onBackPressed(){
    if(web!=null){
      web.evaluateJavascript("(function(){var active=document.querySelector('.screen.active');if(active&&active.id!=='home'){window.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape'}));return true;}return false;})()", value->{if(!"true".equals(value))finish();});
    }else super.onBackPressed();
  }
}
